tinyMCE.addI18n('fr.captionfilter', {
  desc : 'Ajouter une légende à une image',
});
