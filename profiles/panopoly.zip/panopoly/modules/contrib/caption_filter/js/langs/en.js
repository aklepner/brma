tinyMCE.addI18n('en.captionfilter', {
  desc : 'Add a caption to an image',
});
