<div class="app-server clearfix">
  <h3><?php print l($server['title'], 'admin/apps/' . $server['name']); ?></h3>
  <p><?php print $server['description']; ?></p>
</div>
